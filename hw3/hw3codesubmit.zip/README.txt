Name: Dhanush Patel
SID: 3033247258
Reproduction instructions:
- Make sure the required libraries that are imported are installed. I did so in a conda env.
- In the env, run "jupyter lab" or "jupyter notebook" in the same folder as the .ipynb file. Either command should work, but I did the former. 
- Not sure if this will make a difference, but to be safe and get the same results I did, run the cells in order.