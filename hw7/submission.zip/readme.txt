
Name: Dhanush Patel
SID: 3033247258
Reproduction instructions:
- Make sure the required libraries that are imported are installed. I did so in a conda env.
- In the env, run "jupyter lab" or "jupyter notebook" in the same folder as the .ipynb file. Either command should work, but I did the former. 
- Then just "run all" or at least run cells from top to bottom in sequential order to replicate my results